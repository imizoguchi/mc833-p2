for VARIABLE in {1..30}
do
    ./client 189.61.216.125 6

done
